# Scoring and determinism

## Matching rule

A model response is counted as correct if, after **lowercasing and stripping
whitespace**, the expected value satisfies any of:

1. it **equals** the response, or
2. it is **contained in** the response, or
3. it is a **prefix of** the response.

This prefix-tolerant, case-insensitive rule accommodates multi-token semantic
values, where models occasionally emit a trailing qualifier (`alexandrite
gemstone` for `alexandrite`). Spot-checks confirm it does not credit lexically
unrelated strings.

Accuracy for a grid cell is the proportion of correct trials. Confidence
intervals are Wilson 95% intervals on that proportion.

## Primary metric

For each `(K, N)` cell:

```
gap  =  FVQ accuracy  -  CVQ accuracy
```

A gap is called **substantial** when `|gap| > 0.05`.

Two regimes are distinguished:

- **primacy** — FVQ exceeds CVQ.
- **reversal** — CVQ exceeds FVQ, but both sit well below ceiling.

Neither regime is correct retrieval.

## Decoding

All inference uses **greedy decoding (temperature 0)** to eliminate sampling
variance. Every reported number is therefore reproducible from the same model
weights and the same stream.

## Seeding

For each tuple

```
(K, N, query_type, trial_index)
```

a seed is derived by hashing the tuple with BLAKE2b and reading the first 4
bytes as an unsigned integer:

```
key  = "|".join(str(p) for p in parts).encode("utf-8")
seed = int.from_bytes(hashlib.blake2b(key, digest_size=4).digest(), "big")
```

Two properties follow:

- The seed is independent of `PYTHONHASHSEED`, so streams are stable across
  processes and machines.
- The **identical stream** is presented to every condition at the same cell and
  trial index. Base-model and intervention runs are therefore scored on exactly
  the same inputs, and per-trial differences are paired.

The paired property is what makes the within-trial deltas in the causal-ablation
analysis directly comparable between the base and adapted models.
