# Data Card

Two datasets accompany the paper. They share the same `(K, N)` schema and
evaluation grid and differ only in surface form, which is what lets them
separate positional retrieval from semantic shortcuts.

---

## ARBITRARY_SINGLE (ARB)

`pools/arbitrary_single.json`

| | |
|---|---|
| Values | 2,300 |
| Categories | 46 |
| Pool type | Shared — any value may be assigned to any key |
| Token count | Single-token |
| Key–value relation | None |

A pool of common single-token English words. Because the pool is shared, a value
carries no information about which key it belongs to, and there is no reason to
expect any particular ordering among a key's values. This isolates position
tracking from semantic inference.

Single-token values are what make the mechanistic analyses tractable: logit-lens
readout and probing both need the answer to occupy exactly one token position.

**Structure.** `{"metadata": {...}, "values": [...], "categories": [...]}` —
`values` is the flat shared pool; `categories` are the key names.

---

## SEMANTIC_MULTI (SEM)

`pools/semantic_multi.json`

| | |
|---|---|
| Values | 2,403 |
| Categories | 46 |
| Per category | 45–70 |
| Pool type | Per-category |
| Token count | Multi-token |
| Key–value relation | Genuine membership |

Values are real members of their category — `gemstone → alexandrite, amethyst,
…`; `ancient civilization → akkadian, assyrian, …`. This is the primary
behavioural dataset, because realistic key–value semantics rule out the
template-matching strategies a model could use when values are arbitrary.

The smaller per-category pools bound the feasible update count: `N ≤ 50` for most
key counts. Cells that would need more distinct values than a category can supply
are excluded from the grid.

**Structure.** `{"metadata": {...}, "categories": {"<name>": {"values": [...]}}}`.

---

## Construction and provenance

Category names and the semantic value lists were authored for this line of work;
the SEM pool was consolidated and de-duplicated from an earlier version of the
same resource. The ARB word list is common English vocabulary filtered to
single-token status under the tokenisers of the evaluated model families.

No text was scraped from the web, no personal data is present, and no content
was sourced from third-party corpora with redistribution restrictions.

## Intended use

Evaluating in-context state tracking in language models: whether a model can
report the value a variable currently holds after a sequence of overwrites in its
own context. Suitable for behavioural evaluation, adapter training, and
mechanistic analysis.

## Limitations

- **English only.** Category names and values are English; the single-token
  property of ARB is tokeniser-dependent and holds for the model families
  evaluated here, not universally.
- **Synthetic.** Streams are randomly interleaved rather than drawn from natural
  dialogue or documents. This is deliberate — it removes confounds — but it means
  results transfer to applied settings by argument, not by construction.
- **Category coverage.** 46 categories is enough to hold out 11 for
  out-of-distribution evaluation, but it is not a broad ontology.
- **Ceiling effects.** At small `(K, N)` most capable models are at ceiling on
  both queries; the datasets are informative in the mid-to-high load range.

## Ethical considerations

The values are ordinary nouns (colours, gemstones, bird species, board games).
No personal, sensitive, offensive, or identifying content is present, and the
data poses no privacy risk.

## Licence

Released for research use, permitting free use, modification, and redistribution
for research purposes, with attribution to the paper.
