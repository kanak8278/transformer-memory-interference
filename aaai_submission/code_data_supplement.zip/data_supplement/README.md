# Data Supplement

**Tracked but Suppressed: How LLMs Fail State Tracking**

This archive contains the two datasets introduced in the paper and the full
specification needed to rebuild the evaluation instances from them.

It deliberately contains **data and task specification only** — no experiment
code, no model code, no generation pipeline, and no results. Everything here is
declarative: the value pools, and the rules that turn them into prompts.

---

## Contents

```
data_supplement/
├── README.md                     this file
├── DATA_CARD.md                  provenance, composition, licensing, limitations
├── pools/
│   ├── arbitrary_single.json     ARB — 2,300 single-token values, 46 categories
│   └── semantic_multi.json       SEM — 2,403 multi-token values, 46 categories
├── setup/
│   ├── task_spec.json            stream construction, grid, splits, seeding
│   ├── prompts.json              system prompt, query phrasings, 4 stream formats
│   └── scoring.md                matching rule, metric, decoding, determinism
└── examples/
    └── sample_instances.jsonl    9 fully-rendered instances (see below)
```

---

## The task in one paragraph

A stream of `(key, value)` pairs is presented in context. Each of `K` keys is
updated `N` times, and all `K x N` pairs are interleaved in random order, subject
to no two consecutive entries sharing a key. The model is then asked for the
value one target key held at a given position in *its own* update subsequence:
the **first** (FVQ), the **current / last** (CVQ), or an **intermediate** one
(IVQ). Both FVQ and CVQ are answerable from the context alone, so failure
indicates a retrieval problem rather than a capacity limit.

---

## Rebuilding the evaluation set

`setup/task_spec.json` is sufficient to regenerate every instance:

1. Sample `K` categories from the eligible pool; each becomes a key.
2. Draw `N` distinct values per key from that key's pool
   (`pools/*.json`; ARB draws from one shared pool, SEM per-category).
3. Interleave all `K x N` pairs uniformly at random, rejecting any ordering
   where two consecutive entries share a key.
4. Render with one of the four formats in `setup/prompts.json`.
5. Seed each trial by hashing `(K, N, query_type, trial_index)` — see
   `setup/scoring.md`.

**Ground truth is defined by stream order, not draw order.** A key's `k`-th
value is the `k`-th time that key appears *in the rendered stream*. This matters:
because interleaving is random, the order values appear in is not the order they
were drawn from the pool.

Because seeding is deterministic and decoding is greedy, any two conditions
evaluated at the same `(K, N, query_type, trial_index)` see byte-identical
prompts. That is what makes base-vs-intervention comparisons paired.

---

## `examples/sample_instances.jsonl`

Nine fully-rendered instances, one JSON object per line, each with
`system_prompt`, `user_prompt`, and `expected_answer`. They cover:

| # | Dataset | K, N | Format | Query |
|---|---------|------|--------|-------|
| 1–4 | ARB | 2, 3 | plain, labeled, block, landmark | CVQ |
| 5–7 | ARB | 3, 5 | plain | FVQ, CVQ, IVQ |
| 8–9 | SEM | 3, 5 | plain | FVQ, CVQ |

Rows 1–4 are the same task under all four formats, so the surface differences
are directly visible.

These are illustrative, not the evaluation set — the paper's grid spans
`K` up to 30 and `N` up to 100, at up to 200 trials per cell per query type.

Note that rows 1–2 and rows 3–4 have different expected answers despite the same
`(K, N)`: grouped formats (`block`, `landmark`) are built round-major so that
"update rounds" are well defined, while flat formats (`plain`, `labeled`) use a
fully random interleaving. The seed is shared, the stream layout is not.

---

## Licence

Both value pools are released for research use. See `DATA_CARD.md`.
